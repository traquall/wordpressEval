<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wpEval' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Bx08{Vv+NQ2U,DuF3|`;LdkAE?]q~xP-QQC2XSK5xUm,|ebn5aH;rbZF!dAq@q.R');
define('SECURE_AUTH_KEY',  'bA4/|u+o)`PyuP>wu-Jh;vN8c1it<2mCj~ga4aRA2;lq#*p/FT4C@Z5h@r]Qo<+s');
define('LOGGED_IN_KEY',    ' OX9-!Qqf&z^=pBC#@ZD8Ycyup0^p adzBUtB1)Epq/yn9rRC}*j0R ].!c;`Un5');
define('NONCE_KEY',        '!dDM*3xe%n?+!&5/U]Ouv ^h^g5 ,>|1P#pxkFwIQF0/#YIR3+bo`m&LlU/d6A&}');
define('AUTH_SALT',        'X+kfW$UA}mOyOm2Y5SNZzU|K01HcH=b}Ykbp+^5jwzl<`9S[n>Ry&OR{F<5-0)#s');
define('SECURE_AUTH_SALT', 'qsB|VNv2r+,K.5Ko&R(;ADvt.pEL(TM0YV0+a88[;SK4xj,ij<2!0=L%@QOP,nxn');
define('LOGGED_IN_SALT',   'U)9tYAtCfL}KoV|G-4u{mC7sB(+K(+}rN}6lqojuH$hUs.PvjYl(i!z-fJZ4:k{~');
define('NONCE_SALT',       'VZzT?hl6SspBufF!UOy|vS|_)=0Ag9W?i5k@)I-+^+7PCR+mDSSuQ<|@<49<3RHf');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
